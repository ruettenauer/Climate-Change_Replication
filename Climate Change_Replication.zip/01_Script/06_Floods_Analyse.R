
#### Analyses ####
#### Tobias Ruettenauer ####
#### 2020/ 01 / 31 ####

rm(list=ls())

### Load packages
library(rgdal)
library(spdep)
library(rgeos)
library(doParallel)
library(foreign)
library(GISTools)
library(cleangeo)
library(ggplot2)
library(extrafont)
loadfonts()
library(plm)
library(lfe)
library(pglm)
library(lme4)
library(sandwich)
library(lmtest)
library(texreg)
library(stargazer)


#### Extract methods for felm (from github texreg)
extract.felm <- function(model,
                         include.nobs = TRUE,
                         include.rsquared = TRUE,
                         include.adjrs = TRUE,
                         include.fstatistic = FALSE,
                         include.proj.stats = FALSE,
                         include.groups = TRUE,
                         ...) {
  
  s <- summary(model, ...)
  nam <- rownames(s$coefficients)
  co <- s$coefficients[, 1]
  se <- s$coefficients[, 2]
  pval <- s$coefficients[, 4]
  
  gof <- numeric()
  gof.names <- character()
  gof.decimal <- logical()
  if (include.rsquared == TRUE) {
    gof <- c(gof, s$r2)
    gof.decimal <- c(gof.decimal, TRUE)
    if (include.proj.stats == TRUE) {
      gof <- c(gof, s$P.r.squared)
      gof.decimal <- c(gof.decimal, TRUE)
      gof.names <- c(gof.names, "R$^2$ (full model)", "R$^2$ (proj model)")
    } else {
      gof.names <- c(gof.names, "R$^2$")
    }
  }
  if (include.adjrs == TRUE) {
    gof <- c(gof, s$r2adj)
    gof.decimal <- c(gof.decimal, TRUE)
    if (include.proj.stats == TRUE) {
      gof <- c(gof, s$P.adj.r.squared)
      gof.decimal <- c(gof.decimal, TRUE)
      gof.names <- c(gof.names, "Adj. R$^2$ (full model)", "Adj. R$^2$ (proj model)")
    } else {
      gof.names <- c(gof.names, "Adj. R$^2$")
    }
  }
  if (include.fstatistic == TRUE) {
    gof <- c(gof, s$F.fstat[1], s$F.fstat[4])
    gof.decimal <- c(gof.decimal, TRUE, TRUE)
    if (include.proj.stats == TRUE) {
      gof <- c(gof, s$P.fstat[length(s$P.fstat) - 1], s$P.fstat[1])
      gof.decimal <- c(gof.decimal, TRUE, TRUE)
      gof.names <- c(gof.names, "F statistic (full model)",
                     "F (full model): p-value", "F statistic (proj model)",
                     "F (proj model): p-value")
    } else {
      gof.names <- c(gof.names, "F statistic", "F p-value")
    }
  }
  if (include.nobs == TRUE) {
    gof <- c(gof, s$N)
    gof.names <- c(gof.names, "Num. obs.")
    gof.decimal <- c(gof.decimal, FALSE)
  }
  if (include.groups == TRUE && length(s$fe) > 0) {
    grp <- sapply(s$fe, function(x) length(levels(x)))
    grp.names <- paste0("Num. groups: ", names(grp))
    gof <- c(gof, grp)
    gof.names <- c(gof.names, grp.names)
    gof.decimal <- c(gof.decimal, rep(FALSE, length(grp)))
  }
  
  tr <- createTexreg(
    coef.names = nam,
    coef = co,
    se = se,
    pvalues = pval,
    gof.names = gof.names,
    gof = gof,
    gof.decimal = gof.decimal
  )
  return(tr)
}
setMethod("extract", signature = className("felm", "lfe"),
          definition = extract.felm)









### Working Directory
setwd("C:/work/Forschung/Climate Change_Replication/02_Data")


#################
### Load data ###
#################


load("bhpsukhls_flood_final.RData")


### time by region interaction
bhps_flood.df$time_gov <- factor(paste0(bhps_flood.df$istrtdaty, "_", bhps_flood.df$gor_dv))




###---------------------------------###
### Plot worry about climate change ###
###---------------------------------###

res.df <- data.frame(table(bhps_flood.df$scenv_nowo))
res.df$rel <- res.df$Freq / sum(res.df$Freq) *100
res.df$rel_n <- paste0(round(res.df$rel, 2), "%")
res.df$col <- factor(c(1,1,2,3,3))

zp1 <- ggplot(res.df, aes(x = rel, y = Var1, col = ))
zp1 <- zp1 + geom_col(aes(fill = col))
zp1 <- zp1 + geom_segment(aes_all(c('x', 'y', 'xend', 'yend')),
                          data = data.frame(x = c(-1, -0.07), xend = c(-1, 35.05), 
                                            y = c(0.985, 0.42), yend = c(5.015, 0.43)), size = 1.5)
zp1 <- zp1 + geom_text(aes(label = rel_n, x = 1, y = Var1), 
                       size = 5, show.legend  = FALSE, 
                       hjust = 0, vjust = 0.5, color = "white")
zp1 <- zp1 + scale_x_continuous(limits = c(-1, 37),
                   expand = c(0, 0),
                   breaks = c(seq(0,35, 5), 0),
                   labels = c("0%","", "10%","", "20%","", "30%","", "0%"),
                   name = NULL) 
zp1 <- zp1 + scale_fill_manual(values = c("#8c510a", "#80cdc1", "#01665e"), guide = FALSE)
zp1 <- zp1 + scale_y_discrete(name = NULL,
                              breaks = c(1,2,3,4,5, 1),
                              labels = c("strongly agree", 
                                         "tend to agree", 
                                         "neither agree nor disagree", 
                                         "tend to disagree",
                                         "strongly disagree", "strongly disagree"),
                              expand = c(0, 0)) 
zp1 <- zp1 + ggtitle("The effects of climate change are too far in the future to really worry me") 
zp1 <- zp1 + theme_classic(base_size = 20) 
zp1 <- zp1 + theme(axis.line = element_blank(),
                   text = element_text(family = "CM Roman"),
                   plot.title = element_text(face = "italic", hjust = 1.1, size = 22),
                   axis.text.y = element_text( colour = "black"),
                   axis.text.x = element_text( colour = "black"),
                   plot.margin = unit(c(0.1,0.1,1,0.1), "lines"),
                   plot.caption = element_text(size = 12, lineheight = 0.5),)
zp1 <- zp1 + labs(caption = "Understanding Society wave 4 (2012-2014), N = 29,520")
print(zp1)


cairo_pdf(file = paste("../03_Output/", "Climate_worry.pdf", sep=""), width = 10, height = 4, 
          bg = "white", family="CM Roman")
par(mar = c(0, 0, 0, 0))
par(mfrow = c(1, 1), oma = c(0, 0, 0, 0))
zp1
dev.off()




###---------------------------------###
###       Prepare variables         ###
###---------------------------------###


### Flood affected within the last two years

intens <- c("", "3", "10")
buf <- c("3", "2", "1")
for(i in intens){
  for(b in buf){
    v1 <- paste0("flood", i, "_affect_past", b)
    t1 <- paste0("tempdist", i, "_affect_past", b)
    nv <- paste0("flood", i, "_affect2y_past", b)
    nv2 <- paste0("flood", i, "_affectwo2y_past", b)
    
    
    oo <- which(bhps_flood.df[, t1] <= 365*2)
    bhps_flood.df[, nv] <- 0
    bhps_flood.df[oo, nv] <- 1
    
    bhps_flood.df[, nv2] <- bhps_flood.df[, v1] - bhps_flood.df[, nv]
    
  }
}


table(bhps_flood.df$istrtdaty[bhps_flood.df$flood3_affect2y_past3 == 1])
table(bhps_flood.df$istrtdaty[bhps_flood.df$flood3_affect2y_past2 == 1])
table(bhps_flood.df$istrtdaty[bhps_flood.df$flood3_affect2y_past1 == 1])



table(bhps_flood.df$wave[bhps_flood.df$flood3_affect2y_past3 == 1])
table(bhps_flood.df$wave[bhps_flood.df$flood3_affect2y_past2 == 1])
table(bhps_flood.df$wave[bhps_flood.df$flood3_affect2y_past1 == 1])





###-----------------------------------###
###       Reduce to final sample      ###
###-----------------------------------###

depvar <- c("climatechange30", "env_index_all2")
vars <- c("flood_affect2y_past1", "age_cat", "female", "migback", "ethn_dv_short", "hiqual_dv", "child", "marstat_dv", "hhinc_dec", 
          "istrtdaty", "istrtdatm")

for(d in depvar){
  cc <- complete.cases(bhps_flood.df[, c(d, vars)])
  nc <- ave(cc, bhps_flood.df$pidp, FUN = function(x) length(x[x == TRUE]))
  
  bhps_flood.df[, paste0("sample_", d)] <- 0
  oo <- which(cc == TRUE)
  bhps_flood.df[oo, paste0("sample_", d)] <- 1
  
  bhps_flood.df[, paste0("samplefe_", d)] <- 0
  oo <- which(cc == 1 & nc >= 2)
  bhps_flood.df[oo, paste0("samplefe_", d)] <- 1
}





###-----------------------------------###
###          Linear Models            ###
###-----------------------------------###

### Standard lm + controls ###

depvar <- c("climatechange30", "env_index_all2")
intens <- c("", "3", "10")
buffer <- c("3", "2", "1")
i <- intens[2]
lm.l <- vector("list", nrow(expand.grid(buffer)) * 2)

cl <- makeCluster(2)
registerDoParallel(cl)

res1 <- foreach(d = depvar) %dopar% {
  library(lfe)
  names(lm.l) <- paste0(d, c(1:length(lm.l)))
  j <- 1
  for(b in buffer){
    
    v1 <- paste0("flood", i, "_affect2y_past", b)
    ev1 <- paste0("flood", i, "_ever", b)
    
    
    fm1 <- paste0(d, " ~ ", v1)
    fm2 <- paste0(d, " ~ ", v1, 
                          "+ age_cat + female + migback + ethn_dv_short + hiqual_dv + child + marstat_dv + hhinc_dec")
    
    lm1 <- felm(formula(paste0(fm1, " | season_index | 0 | pidp + lsoa01")),
                data = bhps_flood.df[bhps_flood.df[, paste0("sample_", d)] == 1, ],
                psdef = FALSE)
    
    lm2 <- felm(formula(paste0(fm2, " | season_index | 0 | pidp + lsoa01")),
                data = bhps_flood.df[bhps_flood.df[, paste0("sample_", d)] == 1, ],
                psdef = FALSE)
    
    
    
    lm.l[[j]] <- lm1
    lm.l[[j+1]] <- lm2

    j <- j + 2
  }
  res <- lm.l
  res
}
stopCluster(cl)


# Map
ns <- as.list(paste0("flood", i, "_affect2y_past", buffer))
names(ns) <- paste0("flood", i, "_affect2y_past", buffer)

# Climate change
screenreg(res1[[1]], custom.coef.map = ns, digits = 3)
# Envir behav
screenreg(res1[[2]], custom.coef.map = ns, digits = 3)








###----------------------------------###
###           Panel Models           ###
###----------------------------------###

### Create categorical indicator of direction in change

intens <- c("", "3", "10")
buf <- c("3", "2", "1")
for(i in intens){
  for(b in buf){
    
    v1 <- paste0("flood", i, "_affect2y_past", b)
    nv <- paste0("pattern", i, "_affect2y_past", b)
    
    oo <- which(!(bhps_flood.df$wave == 18 | bhps_flood.df$wave == 19))
    bhps_flood.df$tmp1 <- bhps_flood.df[, v1]
    bhps_flood.df[oo, "tmp1"] <- NA
    bhps_flood.df[, "tmp1"] <- ave(bhps_flood.df[, "tmp1"],
                                   bhps_flood.df$pidp,
                                   FUN = function(x) mean(x, na.rm = TRUE)) 
    oo <- which(!bhps_flood.df$wave == 22)
    bhps_flood.df$tmp2 <- bhps_flood.df[, v1]
    bhps_flood.df[oo, "tmp2"] <- NA
    bhps_flood.df[, "tmp2"] <- ave(bhps_flood.df[, "tmp2"],
                                   bhps_flood.df$pidp,
                                   FUN = function(x) mean(x, na.rm = TRUE))
    
    bhps_flood.df[, nv] <- paste(bhps_flood.df$tmp1, bhps_flood.df$tmp2, sep = " - ")
    oo <- grep("NaN", bhps_flood.df[, nv])
    bhps_flood.df[oo, nv] <- NA
    bhps_flood.df[, nv] <- as.factor(bhps_flood.df[, nv])
  }
}


### Standard plm + controls ###

depvar <- c("climatechange30", "env_index_all2")
intens <- c("", "3", "10")
buffer <- c("3", "2", "1")
i <- intens[2]
plm.l <- vector("list", nrow(expand.grid(buffer)) * 2)

cl <- makeCluster(2)
registerDoParallel(cl)

res2 <- foreach(d = depvar) %dopar% {
  library(lfe)
  names(plm.l) <- paste0(d, c(1:length(plm.l)))
  
  j <- 1
  k <- 1
  for(b in buffer){
    
    v1 <- paste0("flood", i, "_affect2y_past", b)
    ev1 <- paste0("flood", i, "_ever", b)

    
    fm1 <- paste0(d, " ~ ", v1, "  + as.factor(season_index)*", ev1)
    fm2 <- paste0(d, " ~ ", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec")
    
    # Estimate via felm with twoway clustered SEs
    bhps_flood.df$interaction <- as.numeric(as.factor(bhps_flood.df$season_index)) * bhps_flood.df[, ev1]

    plm1 <- felm(formula(paste0(fm1, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                 data = bhps_flood.df[bhps_flood.df[, paste0("samplefe_", d)] == 1, ],
                 psdef = FALSE)
    
    plm2 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                 data = bhps_flood.df[bhps_flood.df[, paste0("samplefe_", d)] == 1, ],
                 psdef = FALSE)
    
    
    plm.l[[j]] <- plm1
    plm.l[[j+1]] <- plm2
    j <- j + 2
    
  }
  res <- plm.l
  res
}
stopCluster(cl)


# Map
ns <- as.list(paste0("flood", i, "_affect2y_past", buffer))
names(ns) <- paste0("flood", i, "_affect2y_past", buffer)

# ns2 <- as.list(paste0("flood", intens, "_affectwo2y_past", b))
# names(ns2) <- paste0("flood", intens, "_affectwo2y_past", b)

# Climate change
screenreg(res2[[1]], custom.coef.map = ns, digits = 3)
# Envir behav
screenreg(res2[[2]], custom.coef.map = ns, digits = 3)



# ### Test
# library(lfe)
# est_cl <- felm("climatechange30 ~ flood3_affect2y_past1 + age_cat + hiqual_dv + 
#                  child + marstat_dv + hhinc_dec + as.factor(season_index) * 
#                  flood3_ever1 | pidp | 0 | pidp", 
#                data = bhps_flood.df[bhps_flood.df[, paste0("samplefe_", "climatechange30")] == 1, ])
# summary(est_cl)
# 
# est_cl2 <- felm(climatechange30 ~ flood3_affect2y_past1 + age_cat + hiqual_dv + 
#                  child + marstat_dv + hhinc_dec + as.factor(season_index) * 
#                  flood3_ever1 | pidp | 0 | pidp + lsoa01, 
#                data = bhps_flood.df[bhps_flood.df[, paste0("samplefe_", "climatechange30")] == 1, ])
# summary(est_cl2)




###----------------------------###
###       Export Tables        ###
###----------------------------###

#############
#### OLS ####
#############


### Attitudes

tex_t1 <- texreg(l = res1[[1]],
                 #file="../03_Output/Mod_fe_siting.tex",
                 digits = 3, leading.zero = TRUE,
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:lm_belief_flood",
                 caption = "Linear OLS model. Dep. var.: Belief in climate change.",
                 custom.model.names = c("(1)", "(2)", "(3)", "(4)", "(5)", "(6)"),
                 #groups=list("Census cell level"=1:6, "Community level"=7:nb),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected'),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.rmse = FALSE
)


# Customize
tex_t1 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t1)
tex_t1 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t1, tex_t1, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t1 <- gsub("\n\\begin{table}", head, tex_t1, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{2}{c}{Flood 5km}  & \\multicolumn{2}{c}{Flood 2km}  & \\multicolumn{2}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-3} \\cmidrule(lr){4-5} \\cmidrule(lr){6-7}") 
tex_t1 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t1, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t1 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t1, fixed = TRUE)



bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:lm_belief_flood}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t1, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t1 <- substr(tex_t1, 1, (l-2))
tex_t1 <- sub("$", bottom, tex_t1, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t1, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t1, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t1 <- gsub(tmp, tmp2, tex_t1, fixed = TRUE)

# Print
write.table(tex_t1, file = "../03_Output/Table1_attitudes.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)



### Behaviour

tex_t2 <- texreg(l = res1[[2]],
                 #file="../03_Output/Mod_fe_siting.tex",
                 digits = 3, leading.zero = TRUE,
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:lm_behave_flood",
                 caption = "Linear OLS model. Dep. var.: Pro-environmental behaviour.",
                 custom.model.names = c("(1)", "(2)", "(3)", "(4)", "(5)", "(6)"),
                 #groups=list("Census cell level"=1:6, "Community level"=7:nb),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected'),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.rmse = FALSE
)


# Customize
tex_t2 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t2)
tex_t2 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t2, tex_t2, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t2 <- gsub("\n\\begin{table}", head, tex_t2, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{2}{c}{Flood 5km}  & \\multicolumn{2}{c}{Flood 2km}  & \\multicolumn{2}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-3} \\cmidrule(lr){4-5} \\cmidrule(lr){6-7}") 
tex_t2 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t2, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t2 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t2, fixed = TRUE)



bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:lm_behave_flood}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t2, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t2 <- substr(tex_t2, 1, (l-2))
tex_t2 <- sub("$", bottom, tex_t2, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t2, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t2, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t2 <- gsub(tmp, tmp2, tex_t2, fixed = TRUE)

# Print
write.table(tex_t2, file = "../03_Output/Table2_behav.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)




#############
#### FE ####
#############


### Attitudes

tex_t1 <- texreg(l = res2[[1]],
                 #file="../03_Output/Mod_fe_siting.tex",
                 digits = 3, leading.zero = TRUE, fontsize = "scriptsize",
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:fe_belief_flood",
                 caption = "Individual fixed effects model. Dep. var.: Belief in climate change.",
                 custom.model.names = c("(1)", "(2)", "(3)", "(4)", "(5)", "(6)"),
                 groups=list("Education (ref: GCSE)" = 2:6, 
                             "Marital (ref: married/civil partner)" = 8:12,
                             "Income (ref: lowest decile)" = 13:21),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected',
                                        "hiqual_dv1"            = "Degree",
                                        "hiqual_dv2"            = "Other higher degree",
                                        "hiqual_dv3"            = "A-level etc",
                                        "hiqual_dv5"            = "Other qualification",
                                        "hiqual_dv9"            = "No qualification",
                                        "child"                 = "Child(ren)",
                                        "marstat_dv2"           = "Living as couple",
                                        "marstat_dv3"           = "Widowed",
                                        "marstat_dv4"           = "Divorced",
                                        "marstat_dv5"           = "Separated",
                                        "marstat_dv6"           = "Never married",
                                        "hhinc_dec(1.06,1.52]"  = "Income dec 2",
                                        "hhinc_dec(1.52,1.98]"  = "Income dec 3",
                                        "hhinc_dec(1.98,2.46]"  = "Income dec 4",
                                        "hhinc_dec(2.46,3.01]"  = "Income dec 5",
                                        "hhinc_dec(3.01,3.62]"  = "Income dec 6",
                                        "hhinc_dec(3.62,4.39]"  = "Income dec 7",
                                        "hhinc_dec(4.39,5.38]"  = "Income dec 8",
                                        "hhinc_dec(5.38,7.07]"  = "Income dec 9",
                                        "hhinc_dec(7.07,89.7]"  = "Income dec 10"),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.proj.stats = FALSE
)


# Customize
tex_t1 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t1)
tex_t1 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t1, tex_t1, fixed = TRUE)
tex_t1 <- gsub("pidp", "Person-ID", tex_t1, tex_t1, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t1 <- gsub("\n\\begin{table}", head, tex_t1, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{2}{c}{Flood 5km}  & \\multicolumn{2}{c}{Flood 2km}  & \\multicolumn{2}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-3} \\cmidrule(lr){4-5} \\cmidrule(lr){6-7}") 
tex_t1 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t1, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t1 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t1, fixed = TRUE)




bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\end{scriptsize}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:fe_belief_flood}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t1, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t1 <- substr(tex_t1, 1, (l-2))
tex_t1 <- sub("$", bottom, tex_t1, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t1, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t1, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t1 <- gsub(tmp, tmp2, tex_t1, fixed = TRUE)

# Print
write.table(tex_t1, file = "../03_Output/Table1_fe_attitudes.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)



### Behaviour

tex_t2 <- texreg(l = res2[[2]],
                 #file="../03_Output/Mod_fe_siting.tex",
                 digits = 3, leading.zero = TRUE, fontsize = "scriptsize",
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:fe_behave_flood",
                 caption = "Individual fixed effects model. Dep. var.: Pro-environmental behaviour.",
                 custom.model.names = c("(1)", "(2)", "(3)", "(4)", "(5)", "(6)"),
                 groups=list("Education (ref: GCSE)" = 2:6, 
                             "Marital (ref: married/civil partner)" = 8:12,
                             "Income (ref: lowest decile)" = 13:21),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected',
                                        "hiqual_dv1"            = "Degree",
                                        "hiqual_dv2"            = "Other higher degree",
                                        "hiqual_dv3"            = "A-level etc",
                                        "hiqual_dv5"            = "Other qualification",
                                        "hiqual_dv9"            = "No qualification",
                                        "child"                 = "Child(ren)",
                                        "marstat_dv2"           = "Living as couple",
                                        "marstat_dv3"           = "Widowed",
                                        "marstat_dv4"           = "Divorced",
                                        "marstat_dv5"           = "Separated",
                                        "marstat_dv6"           = "Never married",
                                        "hhinc_dec(1.06,1.52]"  = "Income dec 2",
                                        "hhinc_dec(1.52,1.98]"  = "Income dec 3",
                                        "hhinc_dec(1.98,2.46]"  = "Income dec 4",
                                        "hhinc_dec(2.46,3.01]"  = "Income dec 5",
                                        "hhinc_dec(3.01,3.62]"  = "Income dec 6",
                                        "hhinc_dec(3.62,4.39]"  = "Income dec 7",
                                        "hhinc_dec(4.39,5.38]"  = "Income dec 8",
                                        "hhinc_dec(5.38,7.07]"  = "Income dec 9",
                                        "hhinc_dec(7.07,89.7]"  = "Income dec 10"),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.proj.stats = FALSE
)


# Customize
tex_t2 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t2)
tex_t2 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t2, tex_t2, fixed = TRUE)
tex_t2 <- gsub("pidp", "Person-ID", tex_t2, tex_t2, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t2 <- gsub("\n\\begin{table}", head, tex_t2, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{2}{c}{Flood 5km}  & \\multicolumn{2}{c}{Flood 2km}  & \\multicolumn{2}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-3} \\cmidrule(lr){4-5} \\cmidrule(lr){6-7}") 
tex_t2 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t2, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{No} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t2 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t2, fixed = TRUE)



bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\end{scriptsize}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:fe_behave_flood}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t2, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t2 <- substr(tex_t2, 1, (l-2))
tex_t2 <- sub("$", bottom, tex_t2, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t2, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t2, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t2 <- gsub(tmp, tmp2, tex_t2, fixed = TRUE)

# Print
write.table(tex_t2, file = "../03_Output/Table2_fe_behav.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)









###-----------------------------------------###
###                   Plot                  ###
###-----------------------------------------###

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}



##################
### Attitudes  ###
##################


#### Coefficients Plot ####

# Set up df
eff <- data.frame(matrix(NA, ncol = 7, nrow = 12))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")


eff[1:nrow(eff), 1] <- c(rep(c(1:2), times = 3), rep(c(3:4), times = 3))

eff$modelName <- rep(rep(c(3:1), each = 2), 2)

# Plug in values all
for(i in c(1:6)){
  eff[i, 2:6] <- c(summary(res1[[1]][[i]])$coefficients[1, 1:4], length(res1[[1]][[i]]$residuals))
  eff[i+6, 2:6] <- c(summary(res2[[1]][[i]])$coefficients[1, 1:4], length(res2[[1]][[i]]$residuals))
}


### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = rev(c(1:4)),
                                 labels = rev(c("POLS",
                                                "POLS\n + additional controls",
                                                "FE",
                                                "FE\n + additional controls")))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = c(1:3),
                                  labels = c("Flood 1km", 
                                                 "Flood 2km", 
                                                 "Flood 5km"))


# #  Reorder levels
# allModelFrame$Variable <- factor(allModelFrame$Variable,
#                                levels(allModelFrame$Variable)[rev(c(1,6,2,3,4,5,7))])
# allModelFrame$modelName <- factor(allModelFrame$modelName,
#                                levels(allModelFrame$modelName)[rev(c(1,2))])


# Add to combined df
allModelFrame$eff <- 1
mf_all <- allModelFrame



# Confidence intervals
interval2  <-  -qnorm((1-0.95)/2)  # 95% multiplier

# Colours
# cols <- viridis_pal(begin = 0.2, end = 0.75, direction = 1, option = "magma")(3)
cols <- gg_color_hue(3)


# Plot
zp1 <- ggplot(allModelFrame, aes(colour = modelName, shape = modelName))
zp1 <- zp1 + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
zp1 <- zp1 + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                 ymax = Coefficient + SE*interval2),
                             lwd = 1, position = position_dodge(width = 1/2),
                             fill ="black")
zp1 <- zp1 + coord_flip() + theme_bw()
zp1 <- zp1 + theme(legend.title = element_blank())
zp1 <- zp1 + labs(y = "Coefficients of past flood experience", x = "")
zp1 <- zp1 + scale_shape_manual(values = rev(c(19, 17, 15)), labels = c("Flood 1km", 
                                                                            "Flood 2km",
                                                                            "Flood 5km" )) 
zp1 <- zp1 + scale_color_manual(values = c(cols), labels = c("Flood 1km", 
                                                                 "Flood 2km",
                                                                 "Flood 5km"))
# zp1 <- zp1 + scale_color_hue(direction = -1, h.start=90)
zp1 <- zp1 + theme(text = element_text(family = "CM Roman", size = 20),
                   legend.position = c(0.95,0.99), legend.justification = c(0.95,0.99),
                   legend.background = element_blank(),
                   legend.box.background = element_rect(colour = "black"),
                   legend.key=element_blank(),
                   axis.text.y=element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                   axis.title.x=element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                   axis.text.x = element_text(colour="black"),
                   #axis.text.x = element_text(size=16),
                   #axis.text.y = element_text(size=16),
                   #axis.title.x = element_text(size=16),
                   #axis.title.y = element_text(size=16)
)
zp1 <- zp1 + ggtitle(element_blank())
zp1 <- zp1 + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                    shape = guide_legend(reverse = T))


print(zp1)


cairo_pdf(file="../03_Output/Coefplot1_belief.pdf", width = 9, height = 9, bg = "white", family = "CM Roman")
par(mar=c(0,0,0,0))
par(mfrow=c(1,1),oma=c(0,0,0,0))
zp1
dev.off()






##################
### Behaviour  ###
##################


#### Coefficients Plot ####

# Set up df
eff <- data.frame(matrix(NA, ncol = 7, nrow = 12))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")


eff[1:nrow(eff), 1] <- c(rep(c(1:2), times = 3), rep(c(3:4), times = 3))

eff$modelName <- rep(rep(c(3:1), each = 2), 2)

# Plug in values all
for(i in c(1:6)){
  eff[i, 2:6] <- c(summary(res1[[2]][[i]])$coefficients[1, 1:4], length(res1[[2]][[i]]$residuals))
  eff[i+6, 2:6] <- c(summary(res2[[2]][[i]])$coefficients[1, 1:4], length(res2[[2]][[i]]$residuals))
}



### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = rev(c(1:4)),
                                 labels = rev(c("POLS",
                                                "POLS\n + additional controls",
                                                "FE",
                                                "FE\n + additional controls")))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = c(1:3),
                                  labels = c("Flood 1km", 
                                                 "Flood 2km", 
                                                 "Flood 5km"))


# #  Reorder levels
# allModelFrame$Variable <- factor(allModelFrame$Variable,
#                                levels(allModelFrame$Variable)[rev(c(1,6,2,3,4,5,7))])
# allModelFrame$modelName <- factor(allModelFrame$modelName,
#                                levels(allModelFrame$modelName)[rev(c(1,2))])


# Add to combined df
allModelFrame$eff <- 2
mf_all <- rbind(mf_all, allModelFrame)


# Confidence intervals
interval2  <-  -qnorm((1-0.95)/2)  # 95% multiplier

# Colours
# cols <- viridis_pal(begin = 0.2, end = 0.75, direction = 1, option = "magma")(3)
cols <- gg_color_hue(3)



# Plot
zp3 <- ggplot(allModelFrame, aes(colour = modelName, shape = modelName))
zp3 <- zp3 + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
zp3 <- zp3 + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                 ymax = Coefficient + SE*interval2),
                             lwd = 1, position = position_dodge(width = 1/2),
                             fill ="black")
zp3 <- zp3 + coord_flip() + theme_bw()
zp3 <- zp3 + theme(legend.title = element_blank())
zp3 <- zp3 + labs(y = "Coefficients of past flood experience", x = "")
zp3 <- zp3 + scale_shape_manual(values = rev(c(19, 17, 15)), labels = c("Flood 1km", 
                                                                            "Flood 2km",
                                                                            "Flood 5km")) 
zp3 <- zp3 + scale_color_manual(values = c(cols), labels = c("Flood 1km", 
                                                                 "Flood 2km",
                                                                 "Flood 5km"))
# zp3 <- zp3 + scale_color_hue(direction = -1, h.start=90)
zp3 <- zp3 + theme(text = element_text(family = "CM Roman", size = 20),
                   legend.position = c(0.95,0.99), legend.justification = c(0.95,0.99),
                   legend.background = element_blank(),
                   legend.box.background = element_rect(colour = "black"),
                   legend.key=element_blank(),
                   axis.text.y=element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                   axis.title.x=element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                   axis.text.x = element_text(colour="black"),
                   #axis.text.x = element_text(size=16),
                   #axis.text.y = element_text(size=16),
                   #axis.title.x = element_text(size=16),
                   #axis.title.y = element_text(size=16)
)
zp3 <- zp3 + ggtitle(element_blank())
zp3 <- zp3 + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                    shape = guide_legend(reverse = T))


print(zp3)


cairo_pdf(file="../03_Output/Coefplot3_behav.pdf", width = 9, height = 9, bg = "white", family = "CM Roman")
par(mar=c(0,0,0,0))
par(mfrow=c(1,1),oma=c(0,0,0,0))
zp3
dev.off()





#####################
### Combine Plots ### 
#####################




#### Combine plots ####

mf_all$eff <- factor(mf_all$eff, levels = c(1, 2),
                     labels = c("Climate change belief\n (0 - 1)",
                                "Pro-environmental behaviour\n (1 - 5)"))

# # Set min and max
# mf_all$y_min <- NA
# mf_all$y_min[which(mf_all$eff %in% c("Direct x1", "Direct x2"))] <- -0.3
# mf_all$y_min[which(mf_all$eff %in% c("Indirect x1", "Indirect x2"))] <- -1.5
# 
# mf_all$y_max <- NA
# mf_all$y_max[which(mf_all$eff %in% c("Direct x1", "Direct x2"))] <- 0.7
# mf_all$y_max[which(mf_all$eff %in% c("Indirect x1", "Indirect x2"))] <- 2.2



# Confidence intervals
interval2 <- -qnorm((1-0.95)/2)  # 95% multiplier

mf_all$lb <- mf_all$Coefficient - mf_all$SE * interval2
mf_all$ub <- mf_all$Coefficient + mf_all$SE * interval2

# Set limits (trim data manually)
# xlim = c(-1.5, 2.2)
# 
# mf_all$ub[which(mf_all$ub > mf_all$y_max)] <- mf_all$y_max[which(mf_all$ub > mf_all$y_max)]
# mf_all$lb[which(mf_all$lb < mf_all$y_min)] <- mf_all$y_min[which(mf_all$lb < mf_all$y_min)]

# Coef Labels
mf_all$lab <- as.character(sprintf("%.3f", round(mf_all$Coefficient, 3)))

mf_all$lab[mf_all$p <= 0.1 & mf_all$p > 0.05] <- paste0(mf_all$lab[mf_all$p <= 0.1 & mf_all$p > 0.05], expression("\u2020"))
mf_all$lab[mf_all$p <= 0.05 & mf_all$p > 0.01] <- paste0(mf_all$lab[mf_all$p <= 0.05 & mf_all$p > 0.01], "*")
mf_all$lab[mf_all$p <= 0.01 & mf_all$p > 0.001] <- paste0(mf_all$lab[mf_all$p <= 0.01 & mf_all$p > 0.001], "**")
mf_all$lab[mf_all$p <= 0.001] <- paste0(mf_all$lab[mf_all$p <= 0.001], "***")

# Number of cases position
mf_all$maxx <- ave(mf_all$ub, 
                   by = mf_all$eff,
                   FUN = function(x) max(x))
mf_all$minx <- ave(mf_all$lb, 
                   by = mf_all$eff,
                   FUN = function(x) min(x))

mf_all$tx <- NA
oo <- which(mf_all$modelName == levels(mf_all$modelName)[3])
mf_all$tx[oo] <- mf_all$maxx[oo] - (mf_all$maxx[oo] - mf_all$minx[oo]) * 0.60
oo <- which(mf_all$modelName == levels(mf_all$modelName)[2])
mf_all$tx[oo] <- mf_all$maxx[oo] - (mf_all$maxx[oo] - mf_all$minx[oo]) * 0.38
oo <- which(mf_all$modelName == levels(mf_all$modelName)[1])
mf_all$tx[oo] <- mf_all$maxx[oo] - (mf_all$maxx[oo] - mf_all$minx[oo]) * 0.15

mf_all$ty <- NA
oo <- which(mf_all$Variable %in% levels(mf_all$Variable)[5:6])
mf_all$ty[oo] <- 4.5 
oo <- which(mf_all$Variable %in% levels(mf_all$Variable)[3:4])
mf_all$ty[oo] <- 2.5 
oo <- which(mf_all$Variable %in% levels(mf_all$Variable)[1:2])
mf_all$ty[oo] <- 0.5 


mf_all$tn <- NA
oo <- which(mf_all$modelName == levels(mf_all$modelName)[3])
mf_all$tn[oo] <- "N ="

oo <- which(duplicated(mf_all[, c("eff", "tn", "tx", "ty")]))
mf_all$tn[oo] <- NA

save(mf_all, file = "Coeftable_combined_flood.RData")


# Plot
zp_all <- ggplot(mf_all, aes(colour = modelName, shape = modelName))
zp_all <- zp_all + facet_grid(. ~ eff, scales = "free_x")
zp_all <- zp_all + geom_hline(yintercept = 0, colour = alpha("black", 0.3), lty = 2)
zp_all <- zp_all + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                       ymax = Coefficient + SE*interval2),
                                   lwd = 0.7, position = position_dodge(width = 1/1.8),
                                   fill = "black")
zp_all <- zp_all + geom_text(aes(label = lab,
                                 x = Variable, y = Coefficient), size = 5, show.legend  = FALSE, 
                             hjust = -0.3, vjust = -0.3, position = position_dodge(width = 1/1.8))
zp_all <- zp_all + geom_text(aes(label = N, x = ty, y = tx), 
                             size = 5, show.legend  = FALSE, 
                             hjust = 0, vjust = -0.3)
zp_all <- zp_all + geom_text(data = unique(mf_all[!is.na(mf_all$tn), c("eff", "tn", "tx", "ty", "modelName")]),
                             mapping = aes(label = tn, x = ty, y = tx), size = 5, 
                             show.legend  = FALSE, colour = "black",
                             hjust = 1.3, vjust = -0.3)
zp_all <- zp_all + geom_blank(aes(x = 4.4, y = 0))
zp_all <- zp_all + coord_flip() + theme_bw()
# zp_all <- zp_all + ylim(xlim[1], xlim[2])
# zp_all <- zp_all + geom_blank(aes(y = y_min)) + geom_blank(aes(y = y_max))
zp_all <- zp_all + scale_x_discrete(expand = c(0.05,0.1) )
zp_all <- zp_all + theme(legend.title = element_blank())
zp_all <- zp_all + labs(y = "Coefficients of past flood experience (within 2 years)", x = "")
zp_all <- zp_all + scale_shape_manual(values = rev(c(19, 17, 15)), labels = c("Flood 1km", 
                                                                                  "Flood 2km",
                                                                                  "Flood 5km")) 
zp_all <- zp_all + scale_color_manual(values = c(cols), labels = c("Flood 1km", 
                                                                       "Flood 2km",
                                                                       "Flood 5km"))
zp_all <- zp_all + theme(text = element_text(family = "CM Roman", size = 20),
                         # legend.position = c(0.95, 0.99), legend.justification = c(0.95,0.99),
                         legend.position = "bottom",
                         legend.background = element_blank(),
                         legend.box.background = element_rect(colour = "black"),
                         legend.key = element_blank(),
                         axis.text.y = element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                         axis.title.x = element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                         axis.text.x = element_text(colour="black"),
                         strip.background = element_blank(),
                         strip.text = element_text(size = 20, colour = "black"),
                         #axis.text.x = element_text(size=16),
                         #axis.text.y = element_text(size=16),
                         #axis.title.x = element_text(size=16),
                         #axis.title.y = element_text(size=16)
)
zp_all <- zp_all + ggtitle(element_blank())
zp_all <- zp_all + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                          shape = guide_legend(reverse = T))

zp_all <- zp_all + geom_vline(aes(xintercept = 2.5))
zp_all <- zp_all + geom_vline(aes(xintercept = 4.5))


print(zp_all)

#### Combine plots ####


cairo_pdf(file = paste("../03_Output/", "Coefplot_combined_1.pdf", sep=""), width = 13, height = 10, 
          bg = "white", family="CM Roman")
par(mar = c(0, 0, 0, 0))
par(mfrow = c(1, 1), oma = c(0, 0, 0, 0))
zp_all
dev.off()





### Stepwise plot ###

for(i in c(1:4)){
  
  mf_tmp <- mf_all
  mf_tmp$alpha <- 1
  s <- unlist(list(c(1:6), c(13:18), c(7:12), c(19:24))[1:i])
  mf_tmp$alpha[s] <- 0
  mf_tmp$alpha <- as.factor(mf_tmp$alpha)
  
  zp_all <- ggplot(mf_tmp, aes(colour = modelName, shape = modelName))
  zp_all <- zp_all + facet_grid(. ~ eff, scales = "free_x")
  zp_all <- zp_all + geom_hline(yintercept = 0, colour = alpha("black", 0.3), lty = 2)
  zp_all <- zp_all + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                         ymax = Coefficient + SE*interval2, alpha = alpha),
                                     lwd = 0.7, position = position_dodge(width = 1/1.8),
                                     fill = "black")
  zp_all <- zp_all + geom_text(aes(label = lab, alpha = alpha,
                                   x = Variable, y = Coefficient), size = 5, show.legend  = FALSE, 
                               hjust = -0.3, vjust = -0.3, position = position_dodge(width = 1/1.8))
  zp_all <- zp_all + geom_text(aes(label = N, x = ty, y = tx), 
                               size = 5, show.legend  = FALSE, 
                               hjust = 0, vjust = -0.3)
  zp_all <- zp_all + geom_text(data = unique(mf_all[!is.na(mf_all$tn), c("eff", "tn", "tx", "ty", "modelName")]),
                               mapping = aes(label = tn, x = ty, y = tx), size = 5, 
                               show.legend  = FALSE, colour = "black", 
                               hjust = 1.3, vjust = -0.3)
  zp_all <- zp_all + coord_flip() + theme_bw()
  # zp_all <- zp_all + ylim(xlim[1], xlim[2])
  # zp_all <- zp_all + geom_blank(aes(y = y_min)) + geom_blank(aes(y = y_max))
  zp_all <- zp_all + scale_x_discrete(expand = c(0.05,0.1) )
  zp_all <- zp_all + theme(legend.title = element_blank())
  zp_all <- zp_all + labs(y = "Coefficients of past flood experience (within 2 years)", x = "")
  zp_all <- zp_all + scale_shape_manual(values = rev(c(19, 17, 15)), labels = c("Flood 1km", 
                                                                                "Flood 2km",
                                                                                "Flood 5km")) 
  zp_all <- zp_all + scale_color_manual(values = c(cols), labels = c("Flood 1km", 
                                                                     "Flood 2km",
                                                                     "Flood 5km"))
  zp_all <- zp_all + scale_alpha_manual(values = c(1, 0), guide = FALSE)
  zp_all <- zp_all + theme(text = element_text(family = "CM Roman", size = 20),
                           # legend.position = c(0.95, 0.99), legend.justification = c(0.95,0.99),
                           legend.position = "bottom",
                           legend.background = element_blank(),
                           legend.box.background = element_rect(colour = "black"),
                           legend.key = element_blank(),
                           axis.text.y = element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                           axis.title.x = element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                           axis.text.x = element_text(colour="black"),
                           strip.background = element_blank(),
                           strip.text = element_text(size = 20, colour = "black"),
                           #axis.text.x = element_text(size=16),
                           #axis.text.y = element_text(size=16),
                           #axis.title.x = element_text(size=16),
                           #axis.title.y = element_text(size=16)
  )
  zp_all <- zp_all + ggtitle(element_blank())
  zp_all <- zp_all + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                            shape = guide_legend(reverse = T))
  
  zp_all <- zp_all + geom_vline(aes(xintercept = 2.5))
  zp_all <- zp_all + geom_vline(aes(xintercept = 4.5))
  
  cairo_pdf(file = paste("../03_Output/", "Coefplot_combined_1_", i, ".pdf", sep=""), width = 13, height = 10, 
            bg = "white", family="CM Roman")
  par(mar = c(0, 0, 0, 0))
  par(mfrow = c(1, 1), oma = c(0, 0, 0, 0))
  print(zp_all)
  dev.off()
  
  
}



###-----------------------------------------###
###         Summary statistics              ###
###-----------------------------------------###

bhps_flood.df$index1 <- bhps_flood.df$c_ccexag_w1 + bhps_flood.df$c_ccnoworry_w1 + (1 - bhps_flood.df$c_ccsoondisaster_w1)
bhps_flood.df$index1 <- ifelse(bhps_flood.df$index1 > 0, 1, 0)

bhps_flood.df$index2 <- NA
oo <- which(bhps_flood.df$c_partisan %in% c(2, 3, 4, 5, 6, 8, 9, 11))
bhps_flood.df$index2[oo] <- 1
oo <- which(bhps_flood.df$c_partisan %in% c(95:99))
bhps_flood.df$index2[oo] <- 2
oo <- which(bhps_flood.df$c_partisan %in% c(1, 7, 10, 12, 13, 14))
bhps_flood.df$index2[oo] <- 3

bhps_flood.df$index2 <- as.factor(bhps_flood.df$index2)



### Sample 1

vars <- c("climatechange30", 
          "flood3_affect2y_past1", "flood3_affect2y_past2", "flood3_affect2y_past3", 
          "age_dv", "female", "migback", "ethn_dv_short", "hiqual_dv", "child", 
          "marstat_dv", "hhinc", "index1", "index2")

sample1 <- bhps_flood.df[which(bhps_flood.df$samplefe_climatechange30 == 1), vars]

# Make model frame
oo <- names(Filter(is.factor, sample1))
sample1[, oo] <- droplevels(sample1[, oo])
for(i in oo){
  tmp <-  sapply(levels(sample1[, i]), function(x) as.integer(x == sample1[, i]))
  colnames(tmp) <- paste0(i, "_", colnames(tmp))
  sample1 <- cbind(sample1[, -which(names(sample1) == i)], tmp)
}


stg1 <- stargazer(sample1[ , ], 
          #out = "../03_Output/summarystats1.tex", 
          type = "latex", style = "asr", digits = 3, align = T, 
          summary.stat  =  c("n", "mean", "sd", "min", "max"),
          label  =  "tab:desc1",
          font.size = "scriptsize", 
          table.placement = "h!",
          column.sep.width  =  ".2pt" , title  =  "Estimation sample 1 (Floods - Climate change belief)",
          covariate.labels = c("Climate change belief", 
                               #"Pro-environmental behaviour", 
                               "Flood affected (1km)",   
                               "Flood affected (2km)", 
                               "Flood affected (5km)", 
                               "Age",
                               "Sex (female)", 
                               "Migration background", 
                               "Child(ren) in household",
                               "Household income (in thousand)",  
                               "High scepticism",
                               "XX1 \\quad Any White", 
                               "\\quad Mixed",
                               "\\quad Asian", 
                               "\\quad Black", 
                               "\\quad Other",
                               "XX2 \\quad GCSE etc",
                               "\\quad Degree", 
                               "\\quad Other higher degree", 
                               "\\quad A-level etc",
                               "\\quad Other qualification", 
                               "\\quad No qualification",
                               "XX3 \\quad Married/Civil partner", 
                               "\\quad Living as couple", 
                               "\\quad Widowed/surviving civil partner",
                               "\\quad Divorced/dissolved civil partner", 
                               "\\quad Separated (incl. from civil partner)", 
                               "\\quad Never married",
                               "XX4 \\quad Left-leaning partisanship", 
                               "\\quad No partisanship",
                               "\\quad Right-leaning partisanship"
                               # "XX4 \\quad None",
                               # "\\quad Conservative",
                               # "\\quad Labour",
                               # "\\quad Lib dem /lib/sdp",
                               # "\\quad Scot nat",
                               # "\\quad Plaid cymru",
                               # "\\quad Green party",
                               # "\\quad Ulster unionist",
                               # "\\quad Sdlp",
                               # "\\quad Alliance party",
                               # "\\quad Democratic unionist",
                               # "\\quad Sinn fein",
                               # "\\quad Cant vote",
                               # "\\quad Other party"
                               )
)


### Finalize table
stg1 <- gsub("XX1", "Ethnic background & & & &  &  \\\\\\\\ ",
             stg1,)
stg1 <- gsub("XX2", "Highest education & & & &  &  \\\\\\\\ ",
             stg1)
stg1 <- gsub("XX3", "Marital status & & & &  &  \\\\\\\\ ",
             stg1)
stg1 <- gsub("XX4", "Partisanship & & & &  &  \\\\\\\\ ",
             stg1)

stg1 <- gsub(".000", "",
             stg1)

stg1 <- gsub("D{.}{.}{-3} D{.}{.}{-3} D{.}{.}{-3} D{.}{.}{-3} D{.}{.}{-3}", 
             "D{.}{.}{5.0} D{.}{.}{3.3} D{.}{.}{3.3} D{.}{.}{3.3} D{.}{.}{3.3}",
             stg1, fixed = TRUE)

write.table(stg1, file = "../03_Output/summarystats1.tex", 
            quote = FALSE, col.names = FALSE, row.names = FALSE)




### Sample 2

vars <- c("env_index_all2",
          "flood3_affect2y_past1", "flood3_affect2y_past2", "flood3_affect2y_past3", 
          "age_dv", "female", "migback", "ethn_dv_short", "hiqual_dv", "child", 
          "marstat_dv", "hhinc", "index1", "index2")

sample2 <- bhps_flood.df[which(bhps_flood.df$samplefe_env_index_all2 == 1), vars]

# Make model frame
oo <- names(Filter(is.factor, sample2))
sample2[, oo] <- droplevels(sample2[, oo])
for(i in oo){
  tmp <-  sapply(levels(sample2[, i]), function(x) as.integer(x == sample2[, i]))
  colnames(tmp) <- paste0(i, "_", colnames(tmp))
  sample2 <- cbind(sample2[, -which(names(sample2) == i)], tmp)
}


stg2 <- stargazer(sample2[ , ], 
                  #out = "../03_Output/summarystats1.tex", 
                  type = "latex", style = "asr", digits = 3, align = T, 
                  summary.stat  =  c("n", "mean", "sd", "min", "max"),
                  label  =  "tab:desc2",
                  font.size = "scriptsize", 
                  table.placement = "h!",
                  column.sep.width  =  ".2pt" , title  =  "Estimation sample 2 (Floods - Behaviour)",
                  covariate.labels = c(#"Climate change belief", 
                                       "Pro-environmental behaviour", 
                                       "Flood affected (1km)",   
                                       "Flood affected (2km)", 
                                       "Flood affected (5km)", 
                                       "Age",
                                       "Sex (female)", 
                                       "Migration background", 
                                       "Child(ren) in household",
                                       "Household income (in thousand)",  
                                       "High scepticism",
                                       "XX1 \\quad Any White", 
                                       "\\quad Mixed",
                                       "\\quad Asian", 
                                       "\\quad Black", 
                                       "\\quad Other",
                                       "XX2 \\quad GCSE etc",
                                       "\\quad Degree", 
                                       "\\quad Other higher degree", 
                                       "\\quad A-level etc",
                                       "\\quad Other qualification", 
                                       "\\quad No qualification",
                                       "XX3 \\quad Married/Civil partner", 
                                       "\\quad Living as couple", 
                                       "\\quad Widowed/surviving civil partner",
                                       "\\quad Divorced/dissolved civil partner", 
                                       "\\quad Separated (incl. from civil partner)", 
                                       "\\quad Never married",
                                       "XX4 \\quad Left-leaning partisanship", 
                                       "\\quad No partisanship",
                                       "\\quad Right-leaning partisanship"
                                       # "XX4 \\quad None",
                                       # "\\quad Conservative",
                                       # "\\quad Labour",
                                       # "\\quad Lib dem /lib/sdp",
                                       # "\\quad Scot nat",
                                       # "\\quad Plaid cymru",
                                       # "\\quad Green party",
                                       # "\\quad Ulster unionist",
                                       # "\\quad Sdlp",
                                       # "\\quad Alliance party",
                                       # "\\quad Democratic unionist",
                                       # "\\quad Sinn fein",
                                       # "\\quad Cant vote",
                                       # "\\quad Other party"
                                       )
)


### Finalize table
stg2 <- gsub("XX1", "Ethnic background & & & &  &  \\\\\\\\ ",
             stg2,)
stg2 <- gsub("XX2", "Highest education & & & &  &  \\\\\\\\ ",
             stg2)
stg2 <- gsub("XX3", "Marital status & & & &  &  \\\\\\\\ ",
             stg2)
stg2 <- gsub("XX4", "Partisanship & & & &  &  \\\\\\\\ ",
             stg2)

stg2 <- gsub(".000", "",
             stg2)

stg2 <- gsub("D{.}{.}{-3} D{.}{.}{-3} D{.}{.}{-3} D{.}{.}{-3} D{.}{.}{-3}", 
             "D{.}{.}{5.0} D{.}{.}{3.3} D{.}{.}{3.3} D{.}{.}{3.3} D{.}{.}{3.3}",
             stg2, fixed = TRUE)

write.table(stg2, file = "../03_Output/summarystats2.tex", 
            quote = FALSE, col.names = FALSE, row.names = FALSE)







#### Clean up ####

rm(res1, res2)
gc()








###-------------------------------------------------------###
###         Effect heterogeneity - Exaggerated            ###
###-------------------------------------------------------###

bhps_flood.df$index1 <- bhps_flood.df$c_ccexag_w1 + bhps_flood.df$c_ccnoworry_w1 + (1 - bhps_flood.df$c_ccsoondisaster_w1)
bhps_flood.df$index1 <- ifelse(bhps_flood.df$index1 > 0, 1, 0)


### Exag ###

depvar <- c("climatechange30", "env_index_all2")
intens <- c("", "3", "10")
buffer <- c("3", "2", "1")
i <- intens[2]
plm.l <- vector("list", nrow(expand.grid(buffer)) * 1)
plm3.l <- vector("list", nrow(expand.grid(buffer)) * 1) 

res4 <- vector("list", length(depvar)) 

l <- 1
for(d in depvar) {
  library(lfe)
  names(plm.l) <- paste0(d, c(1:length(plm.l)))
  names(plm3.l) <- paste0(d, c(1:length(plm3.l)))
  
  
  j <- 1
  k <- 1
  for(b in buffer){
    
    
    v1 <- paste0("flood", i, "_affect2y_past", b)
    ev1 <- paste0("flood", i, "_ever", b)
    
    fm2 <- paste0(d, " ~ ", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec")
    
    # Estimate via felm with twoway clustered SEs
    bhps_flood.df$interaction <- as.numeric(as.factor(bhps_flood.df$season_index)) * bhps_flood.df[, ev1]
    
    plm2_1 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index1"] == 0), ], 
                   psdef = FALSE)
    
    plm2_2 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index1"] == 1), ], 
                   psdef = FALSE)
    
    
    # Interacted model
    fm3 <- paste0(d, " ~ index1 * (", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec", 
                  "  + as.factor(season_index)*", ev1, ")")
    
    plm3 <- felm(formula(paste0(fm3, " | pidp | 0 | pidp + lsoa01")),
                 data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1), ], 
                 psdef = FALSE)
    
    
    
    plm.l[[j]] <- plm2_1
    plm.l[[j+1]] <- plm2_2
    plm3.l[[k]] <- plm3
    j <- j + 2
    k <- k + 1
    
  }
  res4[[l]] <- list(plm.l,  plm3.l)
  l <- l + 1
}


# Map
ns <- as.list(paste0("flood", i, "_affect2y_past", buffer))
names(ns) <- paste0("flood", i, "_affect2y_past", buffer)

# Climate change
screenreg(res4[[1]][[1]], custom.coef.map = ns, digits = 3)
# Envir behav
screenreg(res4[[2]][[1]], custom.coef.map = ns, digits = 3)

# Climate change int
screenreg(res4[[1]][[2]], digits = 3)

# Envir behav int
screenreg(res4[[2]][[2]], digits = 3)






#######################
#### Export tables ####
#######################


### Behaviour

tex_t2 <- texreg(l = res4[[2]][[2]],
                 digits = 3, leading.zero = TRUE,
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:fe_exag_flood",
                 caption = "Individual fixed effects model. Dep. var.: Pro-environmental behaviour.",
                 custom.model.names = c("(1)", "(2)", "(3)"),
                 #groups=list("Census cell level"=1:6, "Community level"=7:nb),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected',
                                        'index1:flood3_affect2y_past1' =  'Flood affected $\\times$ sceptic',
                                        'index1:flood3_affect2y_past2' =  'Flood affected $\\times$ sceptic',
                                        'index1:flood3_affect2y_past3' =  'Flood affected $\\times$ sceptic'),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.proj.stats = FALSE
)


# Customize
tex_t2 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t2)
tex_t2 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t2, tex_t2, fixed = TRUE)
tex_t2 <- gsub("pidp", "Person-ID", tex_t2, tex_t2, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t2 <- gsub("\n\\begin{table}", head, tex_t2, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{1}{c}{Flood 5km}  & \\multicolumn{1}{c}{Flood 2km}  & \\multicolumn{1}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-2} \\cmidrule(lr){3-3} \\cmidrule(lr){4-4}") 
tex_t2 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t2, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t2 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t2, fixed = TRUE)



bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles. All controls are interacted with the initial scepticism.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:fe_exag_flood}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t2, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t2 <- substr(tex_t2, 1, (l-2))
tex_t2 <- sub("$", bottom, tex_t2, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t2, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t2, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t2 <- gsub(tmp, tmp2, tex_t2, fixed = TRUE)

# Print
write.table(tex_t2, file = "../03_Output/Table2_fe_exag_flood.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)




### Attitues

tex_t1 <- texreg(l = res4[[1]][[2]],
                 # override.se = lapply(res4[[1]][[4]], FUN = function(x) x[, 2])[c(3,2,1)],
                 # override.pvalues = lapply(res4[[1]][[4]], FUN = function(x) x[, 4])[c(3,2,1)],
                 #file="../03_Output/Mod_fe_siting.tex",
                 digits = 3, leading.zero = TRUE,
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:fe_exag_flood2",
                 caption = "Individual fixed effects model. Dep. var.: Belief in climate change.",
                 custom.model.names = c("(1)", "(2)", "(3)"),
                 #groups=list("Census cell level"=1:6, "Community level"=7:nb),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected',
                                        'index1:flood3_affect2y_past1' =  'Flood affected $\\times$ sceptic',
                                        'index1:flood3_affect2y_past2' =  'Flood affected $\\times$ sceptic',
                                        'index1:flood3_affect2y_past3' =  'Flood affected $\\times$ sceptic'),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.proj.stats = FALSE
)


# Customize
tex_t1 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t1)
tex_t1 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t1, tex_t1, fixed = TRUE)
tex_t1 <- gsub("pidp", "Person-ID", tex_t1, tex_t1, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t1 <- gsub("\n\\begin{table}", head, tex_t1, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{1}{c}{Flood 5km}  & \\multicolumn{1}{c}{Flood 2km}  & \\multicolumn{1}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-2} \\cmidrule(lr){3-3} \\cmidrule(lr){4-4}") 
tex_t1 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t1, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t1 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t1, fixed = TRUE)



bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles. All controls are interacted with the initial scepticism.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:fe_exag_flood2}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t1, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t1 <- substr(tex_t1, 1, (l-2))
tex_t1 <- sub("$", bottom, tex_t1, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t1, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t1, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t1 <- gsub(tmp, tmp2, tex_t1, fixed = TRUE)

# Print
write.table(tex_t1, file = "../03_Output/Table2_fe_exag_flood_att.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)





#####################
### Plot results  ###
#####################
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}


#### Coefficients Plot Behaviour ####

# Set up df
eff <- data.frame(matrix(NA, ncol = 7, nrow = 6))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")
eff[, 1] <- rep(c(3:1), each = 2)

eff$modelName <- rep(c(1:2), times = 3)

# Plug in values all
for(i in c(1:6)){
  eff[i, 2:6] <- c(summary(res4[[2]][[1]][[i]])$coefficients[1, 1:4], length(res4[[2]][[1]][[i]]$residuals))
}


### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = c(1:3),
                                 labels = c("Flood 1km",
                                            "Flood 2km",
                                            "Flood 5km"))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = rev(c(1:2)),
                                  labels = rev(c("Low scepticism",
                                             "High scepticism")))

# Add to combined df
allModelFrame$eff <- 1
mf_all <- allModelFrame

# Save to add floodwaves
save(mf_all, file = "Modelframe_exag.RData")


### Plot

# Confidence intervals
interval2  <-  -qnorm((1-0.95)/2)  # 95% multiplier

# Colours
# cols <- viridis_pal(begin = 0.2, end = 0.75, direction = 1, option = "magma")(3)
cols <- gg_color_hue(2)


# Plot
zp1 <- ggplot(allModelFrame, aes(colour = modelName, shape = modelName))
zp1 <- zp1 + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
zp1 <- zp1 + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                 ymax = Coefficient + SE*interval2),
                             lwd = 1, position = position_dodge(width = 1/2),
                             fill ="black")
zp1 <- zp1 + coord_flip() + theme_bw()
zp1 <- zp1 + theme(legend.title = element_blank())
zp1 <- zp1 + labs(y = "Coefficients of past flood experience", x = "")
# zp1 <- zp1 + scale_shape_manual(values = c(17, 15), c("High scepticism",
#                                                             "High scepticism"))
# zp1 <- zp1 + scale_color_manual(values = c(cols), labels = c("Low scepticism",
#                                                              "High scepticism"))
# zp1 <- zp1 + scale_color_hue(direction = -1, h.start=90)
zp1 <- zp1 + theme(text = element_text(family = "CM Roman", size = 20),
                   legend.position = c(0.95,0.99), legend.justification = c(0.95,0.99),
                   legend.background = element_blank(),
                   legend.box.background = element_rect(colour = "black"),
                   legend.key=element_blank(),
                   axis.text.y=element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                   axis.title.x=element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                   axis.text.x = element_text(colour="black"),
                   #axis.text.x = element_text(size=16),
                   #axis.text.y = element_text(size=16),
                   #axis.title.x = element_text(size=16),
                   #axis.title.y = element_text(size=16)
)
zp1 <- zp1 + ggtitle(element_blank())
zp1 <- zp1 + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                    shape = guide_legend(reverse = T))


print(zp1)


cairo_pdf(file="../03_Output/Coefplot_exag.pdf", width = 9, height = 9, bg = "white", family = "CM Roman")
par(mar=c(0,0,0,0))
par(mfrow=c(1,1),oma=c(0,0,0,0))
zp1
dev.off()





### ----- Redo with reduced sample ----- ###


### Reduce to people with zero in first wave

bhps_flood.df <- bhps_flood.df[order(bhps_flood.df$pidp, bhps_flood.df$wave), ]
bhps_flood.df$first_belief <- ave(bhps_flood.df$climatechange30,
                                  bhps_flood.df$pidp,
                                  FUN = function(x) x[1])

### Repeat

depvar <- c("climatechange30")
intens <- c("", "3", "10")
buffer <- c("3", "2", "1")
i <- intens[2]
plm.l <- vector("list", nrow(expand.grid(buffer)) * 1)
plm3.l <- vector("list", nrow(expand.grid(buffer)) * 1) 

res40 <- vector("list", length(depvar)) 

l <- 1
for(d in depvar) {
  library(lfe)
  names(plm.l) <- paste0(d, c(1:length(plm.l)))
  names(plm3.l) <- paste0(d, c(1:length(plm3.l)))
  
  
  j <- 1
  k <- 1
  for(b in buffer){
    
    
    v1 <- paste0("flood", i, "_affect2y_past", b)
    ev1 <- paste0("flood", i, "_ever", b)
    
    fm2 <- paste0(d, " ~ ", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec")
    
    # Estimate via felm with twoway clustered SEs
    bhps_flood.df$interaction <- as.numeric(as.factor(bhps_flood.df$season_index)) * bhps_flood.df[, ev1]
    
    plm2_1 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index1"] == 0 & bhps_flood.df$first_belief == 0), ], 
                   psdef = FALSE)
    
    plm2_2 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index1"] == 1 & bhps_flood.df$first_belief == 0), ], 
                   psdef = FALSE)
    
    
    # Interacted model
    fm3 <- paste0(d, " ~ index1 * (", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec", 
                  "  + as.factor(season_index)*", ev1, ")")
    
    plm3 <- felm(formula(paste0(fm3, " | pidp | 0 | pidp + lsoa01")),
                 data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1  & bhps_flood.df$first_belief == 0), ], 
                 psdef = FALSE)
    
    
    
    plm.l[[j]] <- plm2_1
    plm.l[[j+1]] <- plm2_2
    plm3.l[[k]] <- plm3
    j <- j + 2
    k <- k + 1
    
  }
  res40[[l]] <- list(plm.l,  plm3.l)
  l <- l + 1
}


# # Map
# ns <- as.list(paste0("flood", i, "_affect2y_past", buffer))
# names(ns) <- paste0("flood", i, "_affect2y_past", buffer)
# 
# # Climate change
# screenreg(res40[[1]][[1]], custom.coef.map = ns, digits = 3)
# # Envir behav
# screenreg(res40[[2]][[1]], custom.coef.map = ns, digits = 3)
# 
# # Climate change int
# screenreg(res40[[1]][[2]], digits = 3)
# 
# # Envir behav int
# screenreg(res40[[2]][[2]], digits = 3)






#### Export Modelframe Belief ####

# Set up df
eff <- data.frame(matrix(NA, ncol = 7, nrow = 6))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")
eff[, 1] <- rep(c(3:1), each = 2)

eff$modelName <- rep(c(1:2), times = 3)

# Plug in values all
for(i in c(1:6)){
  eff[i, 2:6] <- c(summary(res40[[1]][[1]][[i]])$coefficients[1, 1:4], length(res40[[1]][[1]][[i]]$residuals))
}


### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = c(1:3),
                                 labels = c("Flood 1km",
                                            "Flood 2km",
                                            "Flood 5km"))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = rev(c(1:2)),
                                  labels = rev(c("Low scepticism",
                                                 "High scepticism")))

# Add to combined df
allModelFrame$eff <- 1
mf_all <- allModelFrame

# Save to add floodwaves
save(mf_all, file = "Subset0_Modelframe_exag_att.RData")









#### Coefficients Plot Belief ####

# Set up df
eff <- data.frame(matrix(NA, ncol = 7, nrow = 6))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")
eff[, 1] <- rep(c(3:1), each = 2)

eff$modelName <- rep(c(1:2), times = 3)

# Plug in values all
for(i in c(1:6)){
  eff[i, 2:6] <- c(summary(res4[[1]][[1]][[i]])$coefficients[1, 1:4], length(res4[[1]][[1]][[i]]$residuals))
}


### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = c(1:3),
                                 labels = c("Flood 1km",
                                            "Flood 2km",
                                            "Flood 5km"))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = rev(c(1:2)),
                                  labels = rev(c("Low scepticism",
                                                 "High scepticism")))

# Add to combined df
allModelFrame$eff <- 1
mf_all <- allModelFrame

# Save to add floodwaves
save(mf_all, file = "Modelframe_exag_att.RData")


### Plot

# Confidence intervals
interval2  <-  -qnorm((1-0.95)/2)  # 95% multiplier

# Colours
# cols <- viridis_pal(begin = 0.2, end = 0.75, direction = 1, option = "magma")(3)
cols <- gg_color_hue(2)


# Plot
zp1 <- ggplot(allModelFrame, aes(colour = modelName, shape = modelName))
zp1 <- zp1 + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
zp1 <- zp1 + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                 ymax = Coefficient + SE*interval2),
                             lwd = 1, position = position_dodge(width = 1/2),
                             fill ="black")
zp1 <- zp1 + coord_flip() + theme_bw()
zp1 <- zp1 + theme(legend.title = element_blank())
zp1 <- zp1 + labs(y = "Coefficients of past flood experience", x = "")
# zp1 <- zp1 + scale_shape_manual(values = c(17, 15), c("High scepticism",
#                                                             "High scepticism"))
# zp1 <- zp1 + scale_color_manual(values = c(cols), labels = c("Low scepticism",
#                                                              "High scepticism"))
# zp1 <- zp1 + scale_color_hue(direction = -1, h.start=90)
zp1 <- zp1 + theme(text = element_text(family = "CM Roman", size = 20),
                   legend.position = c(0.95,0.99), legend.justification = c(0.95,0.99),
                   legend.background = element_blank(),
                   legend.box.background = element_rect(colour = "black"),
                   legend.key=element_blank(),
                   axis.text.y=element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                   axis.title.x=element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                   axis.text.x = element_text(colour="black"),
                   #axis.text.x = element_text(size=16),
                   #axis.text.y = element_text(size=16),
                   #axis.title.x = element_text(size=16),
                   #axis.title.y = element_text(size=16)
)
zp1 <- zp1 + ggtitle(element_blank())
zp1 <- zp1 + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                    shape = guide_legend(reverse = T))


print(zp1)


cairo_pdf(file="../03_Output/Coefplot_exag.pdf", width = 9, height = 9, bg = "white", family = "CM Roman")
par(mar=c(0,0,0,0))
par(mfrow=c(1,1),oma=c(0,0,0,0))
zp1
dev.off()






















###--------------------------------------------------------###
###         Effect heterogeneity - partisanship            ###
###--------------------------------------------------------###



bhps_flood.df$index2 <- ifelse(bhps_flood.df$partisan %in% c(1, 7, 12, 14), 1, 0)

bhps_flood.df$index2 <- NA
oo <- which(bhps_flood.df$c_partisan %in% c(2, 3, 4, 5, 6, 8, 9, 11))
bhps_flood.df$index2[oo] <- 1
oo <- which(bhps_flood.df$c_partisan %in% c(95:99))
bhps_flood.df$index2[oo] <- 2
oo <- which(bhps_flood.df$c_partisan %in% c(1, 7, 10, 12, 13, 14))
bhps_flood.df$index2[oo] <- 3

bhps_flood.df$index2 <- as.factor(bhps_flood.df$index2)



### parti ###

depvar <- c("climatechange30", "env_index_all2")
intens <- c("", "3", "10")
buffer <- c("3", "2", "1")
i <- intens[2]
plm.l <- vector("list", nrow(expand.grid(buffer)) * 1)
plm3.l <- vector("list", nrow(expand.grid(buffer)) * 1) 

res4 <- vector("list", length(depvar)) 

l <- 1
for(d in depvar) {
  library(lfe)
  names(plm.l) <- paste0(d, c(1:length(plm.l)))
  names(plm3.l) <- paste0(d, c(1:length(plm3.l)))
  
  
  j <- 1
  k <- 1
  for(b in buffer){
    
    
    v1 <- paste0("flood", i, "_affect2y_past", b)
    ev1 <- paste0("flood", i, "_ever", b)
    
    fm2 <- paste0(d, " ~ ", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec")
    
    # Estimate via felm with twoway clustered SEs
    bhps_flood.df$interaction <- as.numeric(as.factor(bhps_flood.df$season_index)) * bhps_flood.df[, ev1]
    
    plm2_1 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index2"] == 1), ], 
                   psdef = FALSE)
    
    plm2_2 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index2"] == 2), ], 
                   psdef = FALSE)
    
    plm2_3 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index2"] == 3), ], 
                   psdef = FALSE)
    
    
    # Interacted model
    fm3 <- paste0(d, " ~ index2 * (", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec", 
                  "  + as.factor(season_index)*", ev1, ")")
    
    plm3 <- felm(formula(paste0(fm3, " | pidp | 0 | pidp + lsoa01")),
                 data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1), ], 
                 psdef = FALSE)
    
    
    
    plm.l[[j]] <- plm2_1
    plm.l[[j+1]] <- plm2_2
    plm.l[[j+2]] <- plm2_3
    plm3.l[[k]] <- plm3
    j <- j + 3
    k <- k + 1
    
  }
  res4[[l]] <- list(plm.l,  plm3.l)
  l <- l + 1
}


# Map
ns <- as.list(paste0("flood", i, "_affect2y_past", buffer))
names(ns) <- paste0("flood", i, "_affect2y_past", buffer)

# Climate change
screenreg(res4[[1]][[1]], custom.coef.map = ns, digits = 3)
# Envir behav
screenreg(res4[[2]][[1]], custom.coef.map = ns, digits = 3)

# Climate change int
screenreg(res4[[1]][[2]], digits = 3)

# Envir behav int
screenreg(res4[[2]][[2]], digits = 3)






#######################
#### Export tables ####
#######################


### Behaviour

tex_t2 <- texreg(l = res4[[2]][[2]],
                 digits = 3, leading.zero = TRUE,
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:fe_parti_flood",
                 caption = "Individual fixed effects model. Dep. var.: Pro-environmental behaviour.",
                 custom.model.names = c("(1)", "(2)", "(3)"),
                 #groups=list("Census cell level"=1:6, "Community level"=7:nb),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected',
                                        'index22:flood3_affect2y_past1' =  'Flood affected $\\times$ no partisan',
                                        'index22:flood3_affect2y_past2' =  'Flood affected $\\times$ no partisan',
                                        'index22:flood3_affect2y_past3' =  'Flood affected $\\times$ no partisan',
                                        'index23:flood3_affect2y_past1' =  'Flood affected $\\times$ right partisan',
                                        'index23:flood3_affect2y_past2' =  'Flood affected $\\times$ right partisan',
                                        'index23:flood3_affect2y_past3' =  'Flood affected $\\times$ right partisan'),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.proj.stats = FALSE
)


# Customize
tex_t2 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t2)
tex_t2 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t2, tex_t2, fixed = TRUE)
tex_t2 <- gsub("pidp", "Person-ID", tex_t2, tex_t2, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t2 <- gsub("\n\\begin{table}", head, tex_t2, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{1}{c}{Flood 5km}  & \\multicolumn{1}{c}{Flood 2km}  & \\multicolumn{1}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-2} \\cmidrule(lr){3-3} \\cmidrule(lr){4-4}") 
tex_t2 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t2, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t2 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t2, fixed = TRUE)



bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles. All controls are interacted with the time-constant parti level.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:fe_parti_flood}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t2, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t2 <- substr(tex_t2, 1, (l-2))
tex_t2 <- sub("$", bottom, tex_t2, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t2, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t2, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t2 <- gsub(tmp, tmp2, tex_t2, fixed = TRUE)

# Print
write.table(tex_t2, file = "../03_Output/Table2_fe_parti_flood.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)




### Attitues

tex_t1 <- texreg(l = res4[[1]][[2]],
                 # override.se = lapply(res4[[1]][[4]], FUN = function(x) x[, 2])[c(3,2,1)],
                 # override.pvalues = lapply(res4[[1]][[4]], FUN = function(x) x[, 4])[c(3,2,1)],
                 #file="../03_Output/Mod_fe_siting.tex",
                 digits = 3, leading.zero = TRUE,
                 stars = c(0.001, 0.01, 0.05, 0.1),
                 symbol = "\\dagger",
                 label = "tab:fe_parti_flood2",
                 caption = "Individual fixed effects model. Dep. var.: Belief in climate change.",
                 custom.model.names = c("(1)", "(2)", "(3)"),
                 #groups=list("Census cell level"=1:6, "Community level"=7:nb),
                 custom.coef.map = list('flood3_affect2y_past1' =  'Flood affected',
                                        'flood3_affect2y_past2' =  'Flood affected',
                                        'flood3_affect2y_past3' =  'Flood affected',
                                        'index22:flood3_affect2y_past1' =  'Flood affected $\\times$ no partisan',
                                        'index22:flood3_affect2y_past2' =  'Flood affected $\\times$ no partisan',
                                        'index22:flood3_affect2y_past3' =  'Flood affected $\\times$ no partisan',
                                        'index23:flood3_affect2y_past1' =  'Flood affected $\\times$ right partisan',
                                        'index23:flood3_affect2y_past2' =  'Flood affected $\\times$ right partisan',
                                        'index23:flood3_affect2y_past3' =  'Flood affected $\\times$ right partisan'),
                 custom.note = "%stars. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA).",
                 dcolumn = TRUE, caption.above = TRUE, use.packages = FALSE, include.proj.stats = FALSE
)


# Customize
tex_t1 <- gsub("D[{].[}][{].[}][{][[:digit:]]+\\.*[[:digit:]]*[}]", "D{.}{.}{2.4}", tex_t1)
tex_t1 <- gsub("\\hline", "\\hline\\\\[-1.2ex]", tex_t1, tex_t1, fixed = TRUE)
tex_t1 <- gsub("pidp", "Person-ID", tex_t1, tex_t1, fixed = TRUE)



head <- c("\\centering\n\\footnotesize\n{\\begin{threeparttable}")
tex_t1 <- gsub("\n\\begin{table}", head, tex_t1, fixed = TRUE)

head2 <- c("\\hline\\\\[-1.2ex] \n  & \\multicolumn{1}{c}{Flood 5km}  & \\multicolumn{1}{c}{Flood 2km}  & \\multicolumn{1}{c}{Flood 1km}  \\\\ 
           \\cmidrule(lr){2-2} \\cmidrule(lr){3-3} \\cmidrule(lr){4-4}") 
tex_t1 <- sub("\\hline\\\\[-1.2ex]", head2, tex_t1, fixed = TRUE)

cont <- paste0("\\hline\\\\[-1.2ex]
  Basic controls &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes} &  \\multicolumn{1}{c}{Yes}   \\\\
  Additional controls & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes} & \\multicolumn{1}{c}{Yes}  \\\\
 \\hline\\\\[-1.2ex]\n","R$^2$")
tex_t1 <- sub("\\hline\\\\[-1.2ex]\nR$^2$", cont, tex_t1, fixed = TRUE)



bottom <- paste0("\n\\\\hline\\\\\\\\[-1.2ex]\n ",
                 "\\\\end{tabular}\n ",
                 "\\\\begin{tablenotes}\n ",
                 "\\\\item \\\\scriptsize{$^{***}p<0.001$, $^{**}p<0.01$, $^*p<0.05$, $^{\\\\dagger}p<0.1$. Two-sided test. Cluster robust standard errors in parentheses (clustered by person and LSOA). Basic controls: year-season of interview (omitted). Additional controls: age (5 year intervals, omitted), highest education, child(ren), marital status, household income deciles. All controls are interacted with the time-constant parti level.}\n",
                 "\\\\end{tablenotes}\n",
                 "\\\\label{tab:fe_parti_flood2}\n",
                 "\\\\end{center}\n",
                 "\\\\end{threeparttable}\n",
                 "}\n")
l <- gregexpr("\\hline\\\\[-1.2ex]", tex_t1, fixed = TRUE)
l <- l[[1]][length(l[[1]])]
tex_t1 <- substr(tex_t1, 1, (l-2))
tex_t1 <- sub("$", bottom, tex_t1, fixed = FALSE)

# N into middle
l1 <- gregexpr("Num. obs", tex_t1, fixed = TRUE)
l1 <- l1[[1]][length(l1[[1]])]


tmp <- substr(tex_t1, l1, (l-2))
tmp2 <- gsub("([[:digit:]]+)", "\\\\multicolumn{1}{c}{\\1}", tmp)
tex_t1 <- gsub(tmp, tmp2, tex_t1, fixed = TRUE)

# Print
write.table(tex_t1, file = "../03_Output/Table2_fe_parti_flood_att.tex",
            col.names = FALSE, row.names = FALSE, quote = FALSE)





#####################
### Plot results  ###
#####################
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}


#### Coefficients Plot Behaviour ####

# Set up df]
eff <- data.frame(matrix(NA, ncol = 7, nrow = 9))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")
eff[, 1] <- rep(c(3:1), each = 3)

eff$modelName <- rep(c(1:3), times = 3)

# Plug in values all
for(i in c(1:9)){
  eff[i, 2:6] <- c(summary(res4[[2]][[1]][[i]])$coefficients[1, 1:4], length(res4[[2]][[1]][[i]]$residuals))
}


### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = c(1:3),
                                 labels = c("Flood 1km",
                                            "Flood 2km",
                                            "Flood 5km"))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = rev(c(1:3)),
                                  labels = rev(c("Left-leaning \n partisanship",
                                                 "No partisanship",
                                                 "Right-leaning \n partisanship")))

# Add to combined df
allModelFrame$eff <- 1
mf_all <- allModelFrame

# Save to add floodwaves
save(mf_all, file = "Modelframe_parti.RData")


### Plot

# Confidence intervals
interval2  <-  -qnorm((1-0.95)/2)  # 95% multiplier

# Colours
# cols <- viridis_pal(begin = 0.2, end = 0.75, direction = 1, option = "magma")(3)
cols <- gg_color_hue(2)


# Plot
zp1 <- ggplot(allModelFrame, aes(colour = modelName, shape = modelName))
zp1 <- zp1 + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
zp1 <- zp1 + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                 ymax = Coefficient + SE*interval2),
                             lwd = 1, position = position_dodge(width = 1/2),
                             fill ="black")
zp1 <- zp1 + coord_flip() + theme_bw()
zp1 <- zp1 + theme(legend.title = element_blank())
zp1 <- zp1 + labs(y = "Coefficients of past flood experience", x = "")
# zp1 <- zp1 + scale_shape_manual(values = c(17, 15), c("Right-leaning \n partisanship",
#                                                             "Right-leaning \n partisanship"))
# zp1 <- zp1 + scale_color_manual(values = c(cols), labels = c("No right-leaning \n partisanship",
#                                                              "Right-leaning \n partisanship"))
# zp1 <- zp1 + scale_color_hue(direction = -1, h.start=90)
zp1 <- zp1 + theme(text = element_text(family = "CM Roman", size = 20),
                   legend.position = c(0.95,0.99), legend.justification = c(0.95,0.99),
                   legend.background = element_blank(),
                   legend.box.background = element_rect(colour = "black"),
                   legend.key=element_blank(),
                   axis.text.y=element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                   axis.title.x=element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                   axis.text.x = element_text(colour="black"),
                   #axis.text.x = element_text(size=16),
                   #axis.text.y = element_text(size=16),
                   #axis.title.x = element_text(size=16),
                   #axis.title.y = element_text(size=16)
)
zp1 <- zp1 + ggtitle(element_blank())
zp1 <- zp1 + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                    shape = guide_legend(reverse = T))


print(zp1)


cairo_pdf(file="../03_Output/Coefplot_parti.pdf", width = 9, height = 9, bg = "white", family = "CM Roman")
par(mar=c(0,0,0,0))
par(mfrow=c(1,1),oma=c(0,0,0,0))
zp1
dev.off()




### ----- Redo with reduced sample ----- ###


### Reduce to people with zero in first wave

bhps_flood.df <- bhps_flood.df[order(bhps_flood.df$pidp, bhps_flood.df$wave), ]
bhps_flood.df$first_belief <- ave(bhps_flood.df$climatechange30,
                                  bhps_flood.df$pidp,
                                  FUN = function(x) x[1])

### Repeat


depvar <- c("climatechange30")
intens <- c("", "3", "10")
buffer <- c("3", "2", "1")
i <- intens[2]
plm.l <- vector("list", nrow(expand.grid(buffer)) * 1)
plm3.l <- vector("list", nrow(expand.grid(buffer)) * 1) 

res4 <- vector("list", length(depvar)) 

l <- 1
for(d in depvar) {
  library(lfe)
  names(plm.l) <- paste0(d, c(1:length(plm.l)))
  names(plm3.l) <- paste0(d, c(1:length(plm3.l)))
  
  
  j <- 1
  k <- 1
  for(b in buffer){
    
    
    v1 <- paste0("flood", i, "_affect2y_past", b)
    ev1 <- paste0("flood", i, "_ever", b)
    
    fm2 <- paste0(d, " ~ ", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec")
    
    # Estimate via felm with twoway clustered SEs
    bhps_flood.df$interaction <- as.numeric(as.factor(bhps_flood.df$season_index)) * bhps_flood.df[, ev1]
    
    plm2_1 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index2"] == 1 & bhps_flood.df$first_belief == 0), ], 
                   psdef = FALSE)
    
    plm2_2 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index2"] == 2 & bhps_flood.df$first_belief == 0), ], 
                   psdef = FALSE)
    
    plm2_3 <- felm(formula(paste0(fm2, " | pidp + season_index + interaction | 0 | pidp + lsoa01")),
                   data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df[, "index2"] == 3 & bhps_flood.df$first_belief == 0), ], 
                   psdef = FALSE)
    
    
    # Interacted model
    fm3 <- paste0(d, " ~ index2 * (", v1, 
                  "+ age_cat + hiqual_dv + child + marstat_dv + hhinc_dec", 
                  "  + as.factor(season_index)*", ev1, ")")
    
    plm3 <- felm(formula(paste0(fm3, " | pidp | 0 | pidp + lsoa01")),
                 data = bhps_flood.df[which(bhps_flood.df[, paste0("samplefe_", d)] == 1 & bhps_flood.df$first_belief == 0), ], 
                 psdef = FALSE)
    
    
    
    plm.l[[j]] <- plm2_1
    plm.l[[j+1]] <- plm2_2
    plm.l[[j+2]] <- plm2_3
    plm3.l[[k]] <- plm3
    j <- j + 3
    k <- k + 1
    
  }
  res4[[l]] <- list(plm.l,  plm3.l)
  l <- l + 1
}




#### Modelframe Belief ####

# Set up df
eff <- data.frame(matrix(NA, ncol = 7, nrow = 9))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")
eff[, 1] <- rep(c(3:1), each = 3)

eff$modelName <- rep(c(1:3), times = 3)

# Plug in values all
for(i in c(1:9)){
  eff[i, 2:6] <- c(summary(res4[[1]][[1]][[i]])$coefficients[1, 1:4], length(res4[[1]][[1]][[i]]$residuals))
}


### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = c(1:3),
                                 labels = c("Flood 1km",
                                            "Flood 2km",
                                            "Flood 5km"))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = rev(c(1:3)),
                                  labels = rev(c("Left-leaning \n partisanship",
                                                 "No partisanship",
                                                 "Right-leaning \n partisanship")))

# Add to combined df
allModelFrame$eff <- 1
mf_all <- allModelFrame

# Save to add floodwaves
save(mf_all, file = "Subset0_Modelframe_parti_att.RData")








#### Coefficients Plot Belief ####

# Set up df
eff <- data.frame(matrix(NA, ncol = 7, nrow = 9))
colnames(eff) <- c("Variable", "Coefficient", "SE", "t", "p", "N", "modelName")
eff[, 1] <- rep(c(3:1), each = 3)

eff$modelName <- rep(c(1:3), times = 3)

# Plug in values all
for(i in c(1:9)){
  eff[i, 2:6] <- c(summary(res4[[1]][[1]][[i]])$coefficients[1, 1:4], length(res4[[1]][[1]][[i]]$residuals))
}


### Combine df, make labels

allModelFrame <- data.frame(eff)

allModelFrame$Variable <- factor(allModelFrame$Variable, levels = c(1:3),
                                 labels = c("Flood 1km",
                                            "Flood 2km",
                                            "Flood 5km"))

allModelFrame$modelName <- factor(allModelFrame$modelName, levels = rev(c(1:3)),
                                  labels = rev(c("Left-leaning \n partisanship",
                                                 "No partisanship",
                                                 "Right-leaning \n partisanship")))

# Add to combined df
allModelFrame$eff <- 1
mf_all <- allModelFrame

# Save to add floodwaves
save(mf_all, file = "Modelframe_parti_att.RData")


### Plot

# Confidence intervals
interval2  <-  -qnorm((1-0.95)/2)  # 95% multiplier

# Colours
# cols <- viridis_pal(begin = 0.2, end = 0.75, direction = 1, option = "magma")(3)
cols <- gg_color_hue(2)


# Plot
zp1 <- ggplot(allModelFrame, aes(colour = modelName, shape = modelName))
zp1 <- zp1 + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
zp1 <- zp1 + geom_pointrange(aes(x = Variable, y = Coefficient, ymin = Coefficient - SE*interval2,
                                 ymax = Coefficient + SE*interval2),
                             lwd = 1, position = position_dodge(width = 1/2),
                             fill ="black")
zp1 <- zp1 + coord_flip() + theme_bw()
zp1 <- zp1 + theme(legend.title = element_blank())
zp1 <- zp1 + labs(y = "Coefficients of past flood experience", x = "")
# zp1 <- zp1 + scale_shape_manual(values = c(17, 15), c("Right-leaning \n partisanship",
#                                                             "Right-leaning \n partisanship"))
# zp1 <- zp1 + scale_color_manual(values = c(cols), labels = c("No right-leaning \n partisanship",
#                                                              "Right-leaning \n partisanship"))
# zp1 <- zp1 + scale_color_hue(direction = -1, h.start=90)
zp1 <- zp1 + theme(text = element_text(family = "CM Roman", size = 20),
                   legend.position = c(0.95,0.99), legend.justification = c(0.95,0.99),
                   legend.background = element_blank(),
                   legend.box.background = element_rect(colour = "black"),
                   legend.key=element_blank(),
                   axis.text.y=element_text(size=20, colour="black", margin = margin(t = 0, r = 5 , b = 0, l = 0)),
                   axis.title.x=element_text(size=20, colour="black", margin = margin(t = 10, r = 0 , b = 0, l = 0)),
                   axis.text.x = element_text(colour="black"),
                   #axis.text.x = element_text(size=16),
                   #axis.text.y = element_text(size=16),
                   #axis.title.x = element_text(size=16),
                   #axis.title.y = element_text(size=16)
)
zp1 <- zp1 + ggtitle(element_blank())
zp1 <- zp1 + guides(colour = guide_legend(override.aes = list(linetype = 0), reverse = T),
                    shape = guide_legend(reverse = T))


print(zp1)


cairo_pdf(file="../03_Output/Coefplot_parti.pdf", width = 9, height = 9, bg = "white", family = "CM Roman")
par(mar=c(0,0,0,0))
par(mfrow=c(1,1),oma=c(0,0,0,0))
zp1
dev.off()















